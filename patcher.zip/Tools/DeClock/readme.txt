*** DeClock ***

Version:  v1.25
Author:   FONG Chee Keat (cheekeat@iname.com)
Homepage: Windows CE Conservatory (cecon.cjb.net) 
Date:     6 April 1999


--- Description ---

Features:

* Displays time including seconds, day of week, date, monthly calendar
* Up to three different time zone locations
* 12/24-hour format
* Color display - color of all elements configurable
* Most display elements can be turned on/off
* Chime - off, hourly, half-hourly or quarter-hourly; configurable 
  sound and volume settings
* Selectable display font
* Shows time and/or date (configurable) in the taskbar when DeClock is 
  minimized/inactive
* Scales display for 480x240 screens
* Moon phase: accurate to about +/- one day
* PowerAlarm
- configurable duration for alarm and snooze
- select your own wave file to use for alarm, and set its volume 
  independently of system settings
- configurable day-of-week (e.g. make your alarm go off only on weekdays)
- PowerSnooze - every time you hit the snooze button, the snooze time increments!
  (e.g. if you set snooze to 5 mins, and the alarm rings and you're feeling 
  particularly sleepy - hitting snooze twice to give you 10 minutes!
- Will turn on the unit 15 seconds before alarm goes off (good when you're not on
  AC power) and unit will stay on for as long as the alarm rings even when on 
  battery power! Good for heavy sleepers, eh? 
  If DeClock was not running, it'll even launch the application so that the alarm
  can go off! (May not work if DeClock is running from Storage Card)
- You can even enter a description for the alarm to remind you what it's all about.
- Cute icons to show the alarm's state - off, on, ringing, snooze
- Date above alarm shows when alarm is scheduled to go off next
* Use a bitmap as wallpaper (note: larger bitmaps = slower display)

--- Usage Notes ---

To install, simply unzip the file, and copy the executable directly into your 
H/PC. There is no setup program. Do not run the executable on your desktop PC!

For more TrueType fonts, simply copy them from the desktop into your HPC's 
\Windows\Fonts directory.

--- What's New ---

v1.25 (6.4.99)
* DeClock autorun for alarm wake-up can now work when DeClock is running from directory 
  (except maybe the Storage Card). If you move DeClock.exe to another directory, please
  reset the alarm again.
  In the past, this feature will only work if you put DeClock.exe in 
  the "My Handheld PC" (root) or the "Windows" directory.
* Bug fix:World time doesn't mess up anymore when time zone is negative

v1.24 (23.3.99)
* Configurable taskbar display
* GMT values in world time configuration can now handle non-integer values
  (like +11.5)

v1.23 (21.2.99)
* Added moon phase display! Accurate to about +/- one day
* Added button in command bar for Alarm
* Taskbar now shows only date when DeClock is inactive


v1.22 (30.12.98)
* PowerAlarm with PowerSnooze
* Use bitmap as wallpaper

v1.11
* Scales screen if 480x240 display detected

v1.10
* Chime - hourly, half-hourly and quarter-hourly 
* Display font selectable - uses any installed TrueType font 
* Displays time and date in taskbar when DeClock is minimized or not the active window 
* Only one instance of DeClock will run 

v1.00
First public release

--- Disclaimer ---

Use this software at your own risk. By doing so, you agree that I will not be 
held responsible for any damages, either directly or indirectly, resulting from 
the use of this software. This includes but is not limited to - screwing up of 
data, cold-booting the unit, meltdown or incineration of the user's H/PC, 
loss of life or the use of one or more limbs or senses.


