//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PalmPopPad.rc
//

#define IDI_ICON1                       101
#define IDR_MAINMENU                    102
#define IDB_BITMAP1                     103
#define IDB_TOOLBAR_LABEL               104
#define IDB_TOOLBAR_BITMAP              105

#define IDM_NEW          80
#define IDM_OPEN         81
#define IDM_SAVE         82
#define IDM_SAVEAS       83
#define IDM_PRINT        84
#define IDM_EXIT         85

#define IDM_UNDO         90
#define IDM_CUT          91
#define IDM_COPY         92
#define IDM_PASTE        93
#define IDM_CLEAR        94
#define IDM_SELALL       95

#define IDM_FIND         70
#define IDM_NEXT         71
#define IDM_REPLACE      72

#define IDM_FONT         40

#define IDM_HELP         50
#define IDM_ABOUT        51

#define IDD_FNAME        60

// Toolbar ID's
#define TB_STD_FILENEW							450
#define TB_STD_FILEOPEN							451
#define TB_STD_FILESAVE							452
#define TB_STD_CUT									453
#define TB_STD_COPY									454
#define TB_STD_PASTE                456
#define TB_STD_UNDO                 457

#define TB_STD_FIND									460
#define TB_STD_REPLACE							461
#define TB_STD_CLEAR                462
#define TB_STD_SELECTALL            463
#define TB_STD_FINDNEXT             464
#define TB_STD_SETFONT              465


// Bitmaps for toolbar 
// Bitmaps in IDB_TOOLBAR_BITMAP
#define IDB_CLEAR											0 + 15
#define IDB_SELECTALL									1 + 15
#define IDB_FINDNEXT									2 + 15
#define IDB_SETFONT										3 + 15
#define IDB_BLANK0									  4 + 15
#define IDB_BLANK1									  5 + 15
#define IDB_FULLSCREEN								6 + 15


#define EDIT_ID   1001
#define BANDS_ID	1002

#define IDC_STATIC                      -1

#define IDC_NONE                      1001
#define ID_MENUBAND										1002
#define ID_BUTTONBAND0								1003
#define ID_BUTTONBAND1								1004
#define ID_BUTTONBAND2								1005

#define  ID_COMBO											2000

#define IDD_PRINTSETUP                  1539
#define IDD_FIND                        1540
#define IDD_REPLACE                     1541
#define IDD_FONT                        1543
#define IDM_EDIT_WORDWRAP               40001
#define IDM_EDIT_TIMEDATE               40002

#define IDB_FIND_FINDNEXT               1
#define IDB_REPLACE_FINDNEXT            1
#define IDB_FIND_CANCEL                 2
#define IDB_REPLACE_CANCEL              2
#define IDC_FIND_MATCHWHOLEWORD         1000
#define IDB_REPLACE_REPLACE             1024
#define IDB_REPLACE_REPLACEALL          1025
#define IDC_REPLACE_MATCHWHOLEWORD      1040
#define IDC_FIND_MATCHCASE              1041
#define IDC_REPLACE_MATCHCASE           1042
#define IDB_FIND_UP                     1056
#define IDB_FIND_FINDDOWN               1057
#define IDE_FIND_FINDWHAT               1152
#define IDE_REPLACE_FINDWHAT            1153
#define IDE_REPLACE_REPLACEWITH         1154

#define IDB_FONT_OK                     1
#define IDB_FONT_CANCEL                 2
#define IDB_FONT_APPLY                  1026
#define ICB_FONTNAME                    1136
#define ICB_FONTSTYLE                   1137
#define ICB_FONTSIZE                    1138



// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
