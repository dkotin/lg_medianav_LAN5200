/*----------------------
   PalmNotePAD.H header file
  ----------------------*/

#define IDM_NEW          10
#define IDM_OPEN         11
#define IDM_SAVE         12
#define IDM_SAVEAS       13
#define IDM_PRINT        14
#define IDM_EXIT         15

#define IDM_UNDO         20
#define IDM_CUT          21
#define IDM_COPY         22
#define IDM_PASTE        23
#define IDM_CLEAR        24
#define IDM_SELALL       25

#define IDM_FIND         30
#define IDM_NEXT         31
#define IDM_REPLACE      32

#define IDM_FONT         40

#define IDM_HELP         50
#define IDM_ABOUT        51

#define IDD_FNAME        10

// Toolbar ID's
#define TB_STD_FILEOPEN               450
#define TB_IDB_REFRESH								451
#define TB_IDB_BACK										452
#define TB_IDB_FORWARD								453
#define TB_STD_PROPERTIES							454
#define TB_STD_DELETE                 456
#define TB_IDB_FONTUP                 457
#define TB_IDB_FONTDOWN               458

// Bitmaps for toolbar 
// Bitmaps in IDB_TOOLBAR_BITMAP
#define IDB_BACK											0 + 15
#define IDB_FORWARD										1 + 15
#define IDB_REFRESH										2 + 15
#define IDB_FONTUP										3 + 15
#define IDB_FONTDOWN									4 + 15
#define IDB_BLANK1									  5 + 15
#define IDB_FULLSCREEN								6 + 15


#define EDIT_ID   1001
#define BANDS_ID	1002

#define IDC_STATIC                      -1

#define IDC_NONE                      1001
#define ID_MENUBAND										1002
#define ID_BUTTONBAND0								1003
#define ID_BUTTONBAND1								1004
#define ID_BUTTONBAND2								1005

#define  ID_COMBO											2000


