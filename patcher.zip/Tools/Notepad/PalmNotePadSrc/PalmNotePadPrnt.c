/*---------------------------------------------------------------
   PalmNotePadPRNT0.C -- PalmNotePadup Editor Printing Functions (dummy version)
  ---------------------------------------------------------------*/

#include <windows.h>

BOOL PalmNotePadPrntPrintFile (HINSTANCE hInst, HWND hwnd, HWND hwndEdit,
                                     LPTSTR pstrTitleName)
{
//ToDo: Implement printing
return FALSE ;
}
