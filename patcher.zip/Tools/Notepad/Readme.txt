Name: PalmNotepad.exe

Introduction:
	This is a sample application (including source and project files) to demonstrate how you might handle commandbands. It is not fully implemented. Hopefully, it will be in the future. The source code originally was used in Charles Petzolds book 'Programming Windows 95'.

Not done yet:
	UP/DOWN Find and replace
	Non dialog based font/find/replace interface
	Font enumeration
	Time/Date
	Some other things, such as reacting to the Soft Input Panel (SIP)

Requirements:
	The PalmPC SDK and development environments are required to use the source code.	

Have fun.